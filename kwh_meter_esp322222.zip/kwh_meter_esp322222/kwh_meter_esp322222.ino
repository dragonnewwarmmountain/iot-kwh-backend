/*****************************************
 * KWH Meter ESP32 - Advanced JSON Architecture
 * Input  : Sensor Arus ACS712 (D35), Sensor Tegangan ZMPT101B (D34)
 * Output : LCD 16x2 I2C, Buzzer (D14), LED_ESP Onboard (D2)
 * Broker : HiveMQ Cloud (TLS, port 8883)
 * 
 * MODIFIKASI:
 * - LED otomatis: mati di bawah low, ikut manual di antara, kedip di atas high.
 * - Kontrol manual LED via MQTT tetap berlaku (hanya di rentang aman).
 * - Notifikasi alarm (TOPIC_ALARM) dihapus.
 *****************************************/

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include "ACS712.h"
#include <ZMPT101B.h>
#include <LiquidCrystal_I2C.h>
#include <Ticker.h>
#include <EEPROM.h>

// --- PIN DEFINITION ---
const int PIN_SENSOR_ARUS = 35;
const int PIN_SENSOR_TEG  = 34;
const int PIN_LED_ESP     = 2;   // LED biru (Internal ESP32)
const int PIN_BUZZER      = 14;  // Acoustic actuator

// --- WIFI ---
const char* ssid     = "Redmi Note 14 Pro 5G";
const char* password = "1234567821";

// --- MQTT BROKER (HiveMQ Cloud) ---
const char* mqtt_server    = "6b272dbc7df74a23a319e1c26f5fdd26.s1.eu.hivemq.cloud";
const int   mqtt_port      = 8883;
const char* mqtt_user      = "iot_device";
const char* mqtt_pass      = "Kelompok7_IoT123!";
const char* mqtt_client_id = "esp32_kwh_meter_01";
const char* device_id      = "esp32-01";

// --- MQTT TOPICS ---
const char* TOPIC_SENSOR  = "sensor/kwh/data";
const char* TOPIC_COMMAND = "actuator/command";       
const char* TOPIC_CONFIG  = "actuator/config/threshold"; 
String TOPIC_STATUS  = String("iot/") + device_id + "/status";
// TOPIC_ALAM dihapus (tidak digunakan lagi)

// --- DYNAMIC SAFETY THRESHOLDS ---
float power_threshold_high = 30.0;
float power_threshold_low  = 29.0;

// --- SENSOR & KOMPONEN ---
#define SENSITIVITY  797.0
ACS712  ampsSensor(PIN_SENSOR_ARUS, 3.3, 4095, 66);
ZMPT101B voltageSensor(PIN_SENSOR_TEG, 50.0);
LiquidCrystal_I2C lcd(0x27, 16, 2);
Ticker countime;

// --- VARIABEL PENGUKURAN ---
float AmpsRMS, VoltRMS, mA, convA;
float Daya, WH_min, WH, KWH;
int detik, menit, jam, c;
const int WHeeprom_addr = 0;

// --- STATE AKTUATOR & SAFETY ---
bool ledManualState = false;   // State manual dari perintah MQTT (hanya berlaku saat aman)
bool buzzerState    = false;  
bool dangerActive   = false;
bool lastDangerState = false;   // Masih digunakan untuk mendeteksi perubahan status bahaya (tapi notifikasi dihapus)

// --- VARIABEL UNTUK BLINKING LED ---
unsigned long lastBlinkTime = 0;
const long blinkInterval = 500;   // Periode kedip 500 ms
bool blinkState = false;

// --- MQTT CLIENT (TLS) ---
WiFiClientSecure espClient;
PubSubClient mqttClient(espClient);

unsigned long lastPublish = 0;
const long publishInterval = 2000;

// ======================================================================
void timeTicker() {
  detik++;
  if (detik > 59) {
    detik = 0;
    menit++;
    WH_min = Daya / 60.0;
    WH = WH + WH_min;
    KWH = WH / 1000.0;
    simpan_eeprom(WH, WHeeprom_addr);
  }
}

void simpan_eeprom(float nilai, int alamat) {
  byte* byte_ptr = (byte*)&nilai;
  for (int i = 0; i < sizeof(float); i++) {
    EEPROM.write(alamat + i, byte_ptr[i]);
  }
  EEPROM.commit();
}

float baca_eeprom(int alamat) {
  float nilai_baca;
  byte* byte_ptr = (byte*)&nilai_baca;
  for (int i = 0; i < sizeof(float); i++) {
    byte_ptr[i] = EEPROM.read(alamat + i);
  }
  return nilai_baca;
}

void averageAmps() {
  float average = 0;
  for (int i = 0; i < 100; i++) {
    average += ampsSensor.mA_AC();
  }
  mA    = average / 100.0;
  convA = mA / 1000.0;
  AmpsRMS = (0.706 * convA) + 0.0164;
}

// ======================================================================
// FUNGSI UPDATE LED - Otomatis + Manual (hanya di rentang aman)
// ======================================================================
void updateLED() {
  if (Daya >= power_threshold_high) {
    // Mode bahaya: LED berkedip (abaikan manual)
    if (millis() - lastBlinkTime >= blinkInterval) {
      lastBlinkTime = millis();
      blinkState = !blinkState;
      digitalWrite(PIN_LED_ESP, blinkState ? HIGH : LOW);
    }
  } 
  else if (Daya < power_threshold_low) {
    // Daya di bawah ambang bawah: LED mati (abaikan manual)
    digitalWrite(PIN_LED_ESP, LOW);
  } 
  else {
    // Rentang aman: LED mengikuti perintah manual
    digitalWrite(PIN_LED_ESP, ledManualState ? HIGH : LOW);
  }
}

// ======================================================================
// SAFETY CHECK - Hanya untuk buzzer (notifikasi MQTT dihapus)
// ======================================================================
void checkSafetyAlarm() {
  // Update status danger
  if (Daya >= power_threshold_high) {
    dangerActive = true;
  } else if (Daya < power_threshold_low) {
    dangerActive = false;
  }

  // Kontrol buzzer
  if (dangerActive) {
    digitalWrite(PIN_BUZZER, LOW); // Active LOW
  } else {
    digitalWrite(PIN_BUZZER, buzzerState ? LOW : HIGH);
  }

  // (Notifikasi alarm via MQTT dihapus)
}

// ======================================================================
void setupWiFi() {
  Serial.printf("\n[WiFi] Menghubungkan ke %s", ssid);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.printf("\n[WiFi] Terhubung! IP: %s\n", WiFi.localIP().toString().c_str());
}

// ======================================================================
void applyCommand(const String& target, const String& action) {
  String actionUpper = action;
  actionUpper.toUpperCase();

  if (target == "led" || target == "relay") {
    // Simpan state manual, tapi hanya akan diterapkan jika berada di rentang aman
    if (actionUpper == "ON") {
      ledManualState = true;
      Serial.println("[AKTUATOR] LED_ESP manual ON");
    } else if (actionUpper == "OFF") {
      ledManualState = false;
      Serial.println("[AKTUATOR] LED_ESP manual OFF");
    }
    // LED akan diupdate di loop() melalui updateLED()
  }
  else if (target == "buzzer") {
    if (dangerActive) {
      Serial.println("[SAFETY] Buzzer LOCKED. Mengabaikan perintah.");
      return;
    }
    if (actionUpper == "ON") {
      buzzerState = true;
      digitalWrite(PIN_BUZZER, LOW);  
      Serial.println("[AKTUATOR] Buzzer Manual ON");
    } else if (actionUpper == "OFF") {
      buzzerState = false;
      digitalWrite(PIN_BUZZER, HIGH); 
      Serial.println("[AKTUATOR] Buzzer Manual OFF");
    }
  }
}

// ======================================================================
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String topicStr = String(topic);
  String message = "";
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  
  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, message);

  if (error) {
    Serial.print("[ERROR] Failed to parse JSON: ");
    Serial.println(error.c_str());
    return;
  }

  if (topicStr == TOPIC_CONFIG) {
    if (doc.containsKey("high")) power_threshold_high = doc["high"];
    if (doc.containsKey("low"))  power_threshold_low  = doc["low"];
    Serial.printf("[CONFIG] Thresholds Updated -> High: %.2f W, Low: %.2f W\n", power_threshold_high, power_threshold_low);
  }
  else if (topicStr == TOPIC_COMMAND) {
    if (doc.containsKey("target") && doc.containsKey("action")) {
      String target = doc["target"].as<String>();
      String action = doc["action"].as<String>();
      applyCommand(target, action);
    }
  }
}

void reconnectMQTT() {
  while (!mqttClient.connected()) {
    Serial.print("[MQTT] Mencoba koneksi ke HiveMQ Cloud...");
    bool ok = mqttClient.connect(
      mqtt_client_id, mqtt_user, mqtt_pass,
      TOPIC_STATUS.c_str(), 1, true, "offline"
    );
    if (ok) {
      Serial.println(" Terhubung!");
      mqttClient.subscribe(TOPIC_COMMAND);
      mqttClient.subscribe(TOPIC_CONFIG);  
      mqttClient.publish(TOPIC_STATUS.c_str(), "online", true);
    } else {
      Serial.printf(" Gagal (rc=%d), coba lagi 3 detik...\n", mqttClient.state());
      delay(3000);
    }
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(PIN_LED_ESP,   OUTPUT);
  pinMode(PIN_BUZZER,    OUTPUT);

  // Inisialisasi LED mati, buzzer mati (HIGH = off karena active LOW)
  digitalWrite(PIN_LED_ESP,   LOW);
  digitalWrite(PIN_BUZZER,    HIGH);

  lcd.init();
  lcd.backlight();
  lcd.print("KWH Meter ESP32");
  lcd.setCursor(0, 1);
  lcd.print(" = HiveMQ IoT = ");

  setupWiFi();

  espClient.setInsecure();
  mqttClient.setServer(mqtt_server, mqtt_port);
  mqttClient.setCallback(mqttCallback);

  EEPROM.begin(512);
  WH = baca_eeprom(WHeeprom_addr);
  if (isnan(WH)) {
    simpan_eeprom(0.0, WHeeprom_addr);
    WH = 0.0;
  }
  KWH = WH / 1000.0;
  
  voltageSensor.setSensitivity(SENSITIVITY);
  ampsSensor.autoMidPoint();
  delay(2000);

  lcd.clear();
  lcd.print("Siap Monitoring");
  countime.attach(1, timeTicker);
}

void loop() {
  if (!mqttClient.connected()) {
    reconnectMQTT();
  }
  mqttClient.loop();

  averageAmps();
  VoltRMS = voltageSensor.getRmsVoltage() - 7;
  if (AmpsRMS < 0.03 || VoltRMS < 100) AmpsRMS = 0;
  if (VoltRMS < 100) VoltRMS = 0;
  Daya = VoltRMS * AmpsRMS;

  checkSafetyAlarm();

  // --- UPDATE LED (otomatis + manual) ---
  updateLED();

  static unsigned long lastLcdUpdate = 0;
  if (millis() - lastLcdUpdate >= 1000) { 
    lastLcdUpdate = millis();
    c++;
    if (c > 6) c = 0;
    
    if (c >= 3) {
      lcd.setCursor(0, 0);
      lcd.print("WH=");  lcd.print(WH);   lcd.print(" wh       ");
      lcd.setCursor(0, 1);
      lcd.print("KWH="); lcd.print(KWH, 3); lcd.print(" kwh      ");
    } else {
      lcd.setCursor(0, 0);
      lcd.print("I="); lcd.print(AmpsRMS); lcd.print("A V="); lcd.print(VoltRMS, 1); lcd.print("V   ");
      lcd.setCursor(0, 1);
      lcd.print("P="); lcd.print(Daya); lcd.print(" W        ");
    }
  }

  unsigned long now = millis();
  if (now - lastPublish >= publishInterval) {
    lastPublish = now;

    JsonDocument doc;
    doc["voltage"] = round(VoltRMS * 100) / 100.0;
    doc["current"] = round(AmpsRMS * 1000) / 1000.0;
    doc["power"]   = round(Daya * 100) / 100.0;
    doc["energy"]  = round(KWH * 10000) / 10000.0;

    char jsonBuf[128];
    serializeJson(doc, jsonBuf);
    mqttClient.publish(TOPIC_SENSOR, jsonBuf);
  }
}